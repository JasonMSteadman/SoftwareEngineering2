package Speed;

public class Card {
	
	public final int iValue;
	
	public Card(int iValue)
	{
		this.iValue = iValue;
	}
	
	public String toString()
	{
		return iValue + "";
	}	
}
