package Speed;

public class SpeedDriver {
		
	public static void main()
	{
		//Create loop that waits for two users
		boolean bIsPlaying = false;
		
		Board game = new Board();
		String sUserInput;
		while(bIsPlaying)
		{
			
		}
	}	
}
