package playingCards;

import java.util.ArrayList;

/**
*
* @author Taylen Wanner
* @description GroupOfCards class, creates the main ArrayList object
*/
public class CardGroup {

   ArrayList<Card> cardGroup;

   public CardGroup() {
       cardGroup = new ArrayList<Card>();
   }

}